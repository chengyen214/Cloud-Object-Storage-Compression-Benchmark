Please delete any other version of Knot! before installing this one.

Welcome To KNOT!
Thank You For Trying The Evaluation Version, and please consider registering.
We are sure that you will find yourself using KNOT! all the time! 

KNOT! 1.00 EVALUATION VERSION FOR THE 3COM PALMPILOT CONNECTED ORGANIZERS -BY JETWARE.
REMEMBER; YOU WILL GET FREE UPDATES OF THIS PROGRAM, IF YOU REGISTER!


for more info, or registration information, visit our website at:
www.jetware.cjb.net
or, for technical support, or any other questions, e-mail JetWare at:
jetware@hotmail.com

Description:
************
KNOT! is an extremly useful utility that lets you remember EVERYTHING you need to remember. The interface is simple to use and the program is very small!  It is really a To-Do list, but it is designed to actually help you remember better what you need to do. I beleive that the GUI is better than the built in To-Do List. 
You first select from an dropdown list what you need to do (e.g. "buy")you then move over to the right, to the text box. And use graffitii or the on-screen keyboard to write in something. (e.g. cherryl clothes for b-day) You then goto the date line and tap it. A calender comes up and you select a date (e.g. Jan 4th, 2001) Then you click the middle of the 3 buttons near the bottom and the entry is stored. The options are general, such as "tape", "buy", "goto" You should not need any others. There is an "other" option. You can use software such as Backup-Buddy to create a pdb, then use a program that (that the registered version comes with) to convert it into a txt which can be imported into Access, or other DB programs. Also, in the registered version, there is a feature called "note" you can enter a couple of words in the top, dotted line and that note stays there through all your records. You might want to enter something like "Remember to blink" :-) so that you don't have to scroll through all of your entries just to find a certain thing.

What You Get In This ZIP File
****************************
knotevreadme.txt (this document)
knot.prc (the .prc file that you install on your Palm device)
jetware1.gif (JetWare's logo. use it as your wall paper, put it on your website, etc...!)

What You Get By Registering
***********************************

- free tech support for life
- this .zip file (but with much more goodies , the registered version, and the conversion application)
- free updates, whenever they come out, for life!
- a newsletter (you can un-subscribe) that tells you about upcoming updates and tells you about new programs BEFORE they come out!
- A More Organized Life :-)

Frequently Asked Questions
**************************

Q.  So tell me, just what does Knot allow me to do? 
  A. It is really a To-Do list, but it is designed to actually help you remember better what you need to do.

  Q.What are the improvements
  over the built-in ToDo list? 
  A. I beleive that the GUI is better. You are correct. You first select from an un-editable dropdown list
  (there is an "other" option, though) what you need to do (e.g. "buy")you then move over to the right,
  to the text box. And use graffitii to write in something. (e.g. cherryl clothes for b-day) you then goto the
  dotted line a tap it. A calender comes up and you select a date (e.g. Jan 4th, 2001) Then you click the
  middle of the 3 buttons near the bottom and the entry is stored. 

  Q.There appears to be a drop-down list to
  select what type of ToDo you are creating, what are the options? Are
  they editable?
  A. The options are general, such as "tape", "buy", "goto" You should not need any others. No. But
  there is a "other" option

  Q. Does Knot use the existing ToDo DB? 
  A. No. 

  Q. Does it integrate
  with anything on the desktop? 
  A. You can use software such as Backup-Buddy to create a pdb, then use a program that I can e-mail to
  you to convert it into a txt which can be imported into Access, or other DB programs...


I NEED HELP!!!!
***************
Just e-mail Jetware @ jetware@hotmail.com and we will answer your question in less than a day! For immediate tech support, call 908-755-2380 and if you leave a voice mail, be sure to leave your phone number!



