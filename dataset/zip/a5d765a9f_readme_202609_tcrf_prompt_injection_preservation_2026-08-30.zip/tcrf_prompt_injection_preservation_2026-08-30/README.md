# TCRF agent prompt-injection preservation bundle

Created: 2026-08-30

Purpose: preserve publicly available evidence relating to the reported 2026-08-05 agent-specific prompt-injection response served by tcrf.net after the original GitHub evidence repository disappeared.

## Critical provenance distinction

The original 2832-byte body has NOT been recovered byte-for-byte in this bundle.

The historical SHA-256 reported for that body was:

`f1e225667a71a1a25ed14795c741683be95139c194065c6fbf861c9280f0096e`

The included payload file is a reconstruction from a surviving search-engine index of the deleted GitHub file. Its SHA-256 is:

`e94642d26443979d9b581cb177a4a65f1c06babd3e83ebf3159916698bd2659b`

Do not claim the reconstructed file matches the original hash.

## Contents

- `evidence/reconstructed_payload_from_search_index.html.txt`
  Reconstructed inert text copy of the HTML content retained by web indexing.

- `evidence/original_reported_sha256.txt`
  Historical hash reported by the deleted repository and independent reporting.

- `evidence/reconstruction_sha256.txt`
  Hash of the reconstruction in this archive.

- `evidence/technical_observations.md`
  Preserved technical parameters and UA observations.

- `sources/SOURCES.md`
  Surviving public corroboration and official reporting channels.

- `submission/reporting_routes.md`
  Suggested recipients.

- `submission/report_template.txt`
  Neutral evidence-submission template.

- `MANIFEST_SHA256.txt`
  Hashes of files in this preservation bundle.

## Safety

The payload is stored as `.html.txt` deliberately. It contains instructions aimed at automated agents. Do not feed it into an autonomous agent with filesystem or shell permissions except in a controlled security-testing environment.
