# Suggested reporting routes

## Highest-value security reports

### Anthropic
Reason: Claude Code was reportedly the agent that encountered and rejected the page, and Anthropic explicitly requests logs, proof-of-concept material, URLs, impact, and reproduction details in security reports.

Official policy:
https://www.anthropic.com/responsible-disclosure-policy

Frame it as:
"Third-party web content deliberately serving destructive prompt-injection instructions to Claude/Claude Code user agents."

### OpenAI Safety Bug Bounty / Security
Reason: independent reporting says `ChatGPT-User` received the same payload. OpenAI's 2026 Safety Bug Bounty explicitly lists third-party prompt injection capable of hijacking an agent into harmful actions.

Official:
https://openai.com/index/safety-bug-bounty/
https://openai.com/policies/coordinated-vulnerability-disclosure-policy/

## Infrastructure / abuse

### Linode / Akamai
Official Linode guidance identifies:
abuse@linode.com

Include:
- tcrf.net
- historical IP 198.58.122.110
- capture date 2026-08-05
- original reported SHA-256
- reconstructed sample
- independent source list
- clear statement that the sample is reconstructed from indexes, not claimed byte-identical

## Law enforcement

### FBI IC3
https://complaint.ic3.gov/

IC3 says reports may be filed even when unsure whether the conduct qualifies, and complaints can be referred to federal, state, local, or international law enforcement.

Do not assert that a crime occurred. Report the observed conduct and evidence and ask that it be assessed.

### Australia: ASD/ACSC ReportCyber
https://www.cyber.gov.au/report-and-recover/report

Useful because the reporter is in Australia and ReportCyber can route cybercrime/security reports to relevant Australian law-enforcement or agencies.

## Vulnerability coordination

### CERT/CC
https://www.kb.cert.org/vuls/report/

Best angle: a cross-vendor agent-security pattern, not a demand that CERT investigate the website operator. CERT/CC prioritizes multi-vendor security issues and can coordinate affected vendors.
