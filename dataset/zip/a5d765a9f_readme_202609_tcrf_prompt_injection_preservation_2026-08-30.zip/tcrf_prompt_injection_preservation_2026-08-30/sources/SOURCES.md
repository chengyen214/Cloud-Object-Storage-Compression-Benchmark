# Surviving sources and corroboration

Preserved 2026-08-30.

1. Deleted GitHub repository (now 404)
   - https://github.com/bashalarmistalt/tcrf-ai-agent-payload-report
   - Deleted file path:
     https://github.com/bashalarmistalt/tcrf-ai-agent-payload-report/blob/master/tcrf.net_.agent.html
   - Search indexing still retained the HTML contents after deletion.

2. Tech Bytes independent write-up
   - https://techbytes.app/posts/tcrfnet-served-claude-a-payload-telling-it-to-wipe-the-working-directory/
   - Preserves the UA matrix, reported 2832-byte body size, SHA-256, origin IP/server, Last-Modified value, and description of independent urlscan captures.

3. Open Source Pulse / NotionPulse repository index
   - https://www.notionpulse.cc/
   - Retained listing for `bashalarmistalt/tcrf-ai-agent-payload-report`, describing it as a 2026 HTML repository documenting destructive prompt injection, hashes, headers, UA matrix, and third-party urlscan captures.

4. TCRF public Bluesky material as mirrored by LiveQuote
   - https://www.livequote.org/author?bsky_handle=tcrf.net
   - Preserves contemporaneous public discussion of the prompt-injection controversy, including TCRF's acknowledgement that an AI user received a prompt-injection warning and discussion of the abuse complaint.
   - Also preserves later Linode/TCRF DDoS-status posts.

5. Anthropic responsible disclosure policy
   - https://www.anthropic.com/responsible-disclosure-policy

6. OpenAI coordinated vulnerability disclosure / safety bounty
   - https://openai.com/policies/coordinated-vulnerability-disclosure-policy/
   - https://openai.com/index/safety-bug-bounty/

7. FBI Internet Crime Complaint Center
   - https://www.ic3.gov/
   - https://complaint.ic3.gov/

8. Australian Cyber Security Centre / ReportCyber
   - https://www.cyber.gov.au/report-and-recover/report

9. Linode abuse reporting
   - abuse@linode.com
   - https://www.linode.com/community/questions/18003/how-do-i-submit-abuse-reports

10. CERT Coordination Center vulnerability reporting
   - https://www.kb.cert.org/vuls/report/

Preservation note:
This archive intentionally distinguishes contemporaneous evidence from later reporting and reconstruction. No claim is made that the deleted GitHub repository itself has been recovered byte-for-byte.
