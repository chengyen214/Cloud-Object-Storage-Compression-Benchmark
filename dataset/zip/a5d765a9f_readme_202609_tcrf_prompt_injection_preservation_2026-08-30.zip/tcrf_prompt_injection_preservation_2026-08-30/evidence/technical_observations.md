# Technical observations preserved from independent indexing

Capture date reported by the deleted repository: 2026-08-05

Reported origin:
- Host: tcrf.net
- IP: 198.58.122.110
- Web server: nginx/1.14.0
- Hosting network: Linode
- PTR reportedly resolved to tcrf.net

Reported malicious-response properties:
- HTTP status for selected agent UAs: 200 OK
- Response size: 2832 bytes
- Reported SHA-256: `f1e225667a71a1a25ed14795c741683be95139c194065c6fbf861c9280f0096e`
- Last-Modified: Mon, 20 Jul 2026 11:24:16 GMT
- Vary: User-Agent reportedly absent
- `/favicon.ico` reportedly returned the same agent-specific payload

User-agent observations preserved by independent reporting:
- Payload reported for: Claude-User, ClaudeBot, ClaudeBot/1.0, anthropic, Anthropic-AI, ChatGPT-User
- Ordinary block/403 reported for several others including bare `claude`, GPTBot/1.0, Googlebot/2.1, and Firefox/128.0
- Independent urlscan captures were reported from Spain and Germany and described as byte-identical to the US capture.

Important provenance warning:
The file `reconstructed_payload_from_search_index.html.txt` was reconstructed on 2026-08-30 from a surviving web-search index of the deleted GitHub file. It is NOT asserted to be byte-for-byte identical to the original 2832-byte response. Its local SHA-256 is:

`e94642d26443979d9b581cb177a4a65f1c06babd3e83ebf3159916698bd2659b`

The original reported SHA-256 above must therefore be treated as a historical observation, not as a hash of the reconstructed file.
