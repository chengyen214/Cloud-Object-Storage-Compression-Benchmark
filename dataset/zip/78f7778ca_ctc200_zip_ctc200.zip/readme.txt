Connective Text Clipboard.Version 2.0


What does Connective Text Clipboard do ?
============================================= 
Connective Text Clipboard is a Windows95 based application designed
to store, edit and reuse frequently used snippets of text,which
can be to transfer between program and Windows clipboard.  

Connective Text Clipboard  has 10 independant text fields, so, you can store 
and edit 10 different clipboard data items at the same time.
You can type text into text fields.
Program allow to open file for locate it into the text fields.
Contents of the every text fields can be to save as file.
All of the text fields can be edit, copy and paste.

Program allow to exchange snippets of text with Windows clipboard
Connective Text Clipboard  clear and save contents of the Windows clipboard.
Program really extends the capabilities of the Windows clipboard,
making it a convenient text tool.  

SYSTEM REQUIREMENTS
386/Pentium Processor
Windows95/98/NT


Installation
============
  Unzip the download file into a your own directory.

Status of the program
=====================
This program is demos version that is not fully functional.

Distribution status of the program
==================================
This program is freely distributable.

Contacting the author
=====================
WWW   http://segobit.virtualave.net 
e-mail: serg@logisti�.ryazan.ru


Notes
=====

I hope you will enjoy working with Connective Text Clipboard!
Sergey A. Golovko * 1999
