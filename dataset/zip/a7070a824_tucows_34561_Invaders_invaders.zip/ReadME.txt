Invaders for the Palm 
from Mobile Generation Software

Freeware
Copyright (C) 1999,2000 Mobile Generation Software
All Rights Reserved


For more great PalmOS software, visit www.mobilegeneration.com


Instructions

Invaders for the Palm is strikingly similar to the popular 80's arcade game,
Space Invaders.  Although this version of Invaders was not originally developed 
by Mobile Generation Software, we have recovered the software from the 
early-pilot-day archives and made it available to all Palm users for free.

Basically, the goal is to shoot down all the invading aliens before they
destroy you!


Mobile Generation Software
www.mobilegeneration.com
